package com.cg.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Details;

@Controller
public class ViewPlans {

	@RequestMapping(value = "/home")
	public String getHomePage(Model m) {
		// m.addAttribute("empKey", emp);
		return "link";
	}

	@RequestMapping(value = "/viewall")
	public String view() {
		
		return "view";

	}
}
